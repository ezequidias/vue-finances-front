const Login = () => import('./../views/Login.vue')

export default [
  { path: '/login', component: Login }
]
